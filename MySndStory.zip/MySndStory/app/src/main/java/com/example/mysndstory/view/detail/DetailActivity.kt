package com.example.mysndstory.view.detail

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import com.bumptech.glide.Glide
import com.example.mysndstory.DetailStoryResponse
import com.example.mysndstory.databinding.ActivityDetailBinding
import com.example.mysndstory.helper.ViewModelFactory

class DetailActivity : AppCompatActivity() {
    private val viewModel by viewModels<DetailViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Detail Story"

        val Id = intent.getStringExtra(EXTRA_STORY_ID)
        if (Id != null) {
            viewModel.getStoryId(Id)
        }

        viewModel.detailstory.observe(this) {DetailResponse ->
            setDetailData(DetailResponse)
        }

        viewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    private fun setDetailData(detailStoryResponse: DetailStoryResponse) {
        detailStoryResponse.story?.let { story ->
            binding.tvName.text = story.name
            binding.tvDescription.text = story.description
            Glide.with(this)
                .load(story.photoUrl)
                .into(binding.ivItem)

            ////
//            detailStoryResponse.setOnClickListener {
////                val intent = Intent(detailStoryResponse, DetailActivity::class.java)
//            val optionsCompat: ActivityOptionsCompat =
//                ActivityOptionsCompat.makeSceneTransitionAnimation(
//                    detailStoryResponse as Activity,
//                    Pair(binding.ivItem, "profile"),
//                    Pair(binding.tvName, "name"),
//                    Pair(binding.tvDescription, "description"),
//                )
//            detailStoryResponse.startActivity(intent, optionsCompat.toBundle())
//            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_STORY_ID = "extra_story_id"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}