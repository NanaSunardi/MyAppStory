package com.example.mysndstory.helper

import com.example.mysndstory.DetailStoryResponse
import com.example.mysndstory.UserModel
import com.example.mysndstory.UserPreference
import com.example.mysndstory.data.response.FileUploadResponse
import com.example.mysndstory.data.response.ListStoryResponse
import com.example.mysndstory.data.response.LoginResponse
import com.example.mysndstory.data.response.RegisterResponse
import com.example.mysndstory.data.retrofit.ApiService
import kotlinx.coroutines.flow.Flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class UserRepository (
    private val userPreference: UserPreference,
    private val apiService: ApiService
){
    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    suspend fun register(name: String, email: String, password: String): RegisterResponse {
        return apiService.register(name, email, password)
    }

    suspend fun login(email: String,password: String): LoginResponse {
        val response = apiService.login(email, password)
        if (response.error == false) {
            val userModel = UserModel(email, response.loginResult?.token ?: "")
            userPreference.saveSession(userModel)
        }
        return response
    }

    suspend fun getStory(): ListStoryResponse {
        return apiService.getStory()
    }

    suspend fun getStoryId(id: String): DetailStoryResponse {
        return apiService.getStoryId(id)
    }

    suspend fun uploadImage(file: File, description: String): FileUploadResponse {
        val requestFile = file.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData("photo", file.name, requestFile)
        val descriptionBody = description.toRequestBody("text/plain".toMediaType())
        return apiService.uploadImage(multipartBody, descriptionBody)
    }

    companion object {
        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService
        ) = UserRepository(userPreference, apiService)
    }
}