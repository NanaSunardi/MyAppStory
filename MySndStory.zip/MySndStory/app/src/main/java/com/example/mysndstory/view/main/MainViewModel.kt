package com.example.mysndstory.view.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.mysndstory.UserModel
import com.example.mysndstory.data.response.ErrorResponse
import com.example.mysndstory.data.response.ListStoryResponse
import com.example.mysndstory.helper.UserRepository
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class MainViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val _story = MutableLiveData<ListStoryResponse>()
    val story: LiveData<ListStoryResponse> = _story

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun getSession(): LiveData<UserModel> {
        return userRepository.getSession().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            userRepository.logout()
        }
    }

    fun getStory() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = userRepository.getStory()
                _story.value = response
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                if (errorBody != null && errorBody.startsWith("<html>")) {
                    _story.value = ListStoryResponse(error = true, message = "Received HTML response instead of JSON")
                } else {
                    val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
                    val errorMessage = errorResponse.message
                    _story.value = ListStoryResponse(error = true, message = errorMessage)
                }
            } catch (e: Exception) {
                _story.value = ListStoryResponse(error = true, message = "An error occurred: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }
    }
}