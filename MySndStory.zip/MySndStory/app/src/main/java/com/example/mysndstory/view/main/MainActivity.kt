package com.example.mysndstory.view.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mysndstory.R
import com.example.mysndstory.data.response.ListStoryResponse
import com.example.mysndstory.databinding.ActivityMainBinding
import com.example.mysndstory.helper.ViewModelFactory
import com.example.mysndstory.view.adapter.ListStoryAdapter
import com.example.mysndstory.view.add.AddStoryActivity
import com.example.mysndstory.view.welcome.WelcomeActivity

class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "List Story"

        val layoutManager = LinearLayoutManager(this)
        binding.rvMystory.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvMystory.addItemDecoration(itemDecoration)

        viewModel.story.observe(this) { listStoryResponse ->
            setStoryData(listStoryResponse)
        }

        viewModel.isLoading.observe(this) {
            showLoading(it)
        }

        viewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                viewModel.getStory()
            }
        }

        binding.fabAddMystory.setOnClickListener {
            val intent = Intent(this, AddStoryActivity::class.java)
            startActivity(intent)
        }

        setupView()
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.menu_main, menu)
//        return super.onCreateOptionsMenu(menu)
//    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            android.R.id.home -> {
                AlertDialog.Builder(this)
                    .setMessage("Are you sure to logout")
                    .setPositiveButton("Yes") { dialog, _ ->
                        viewModel.logout()
                        val intent= Intent(this, WelcomeActivity::class.java)
                        startActivity(intent)
                        dialog.dismiss()
                    }
                    .setNegativeButton("No") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setStoryData(listStoryResponse: ListStoryResponse) {
        val consumerStory = listStoryResponse.listStory
        val adapater = ListStoryAdapter()
        adapater.submitList(consumerStory)
        binding.rvMystory.adapter = adapater
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}